Author: Amzuloiu Andrei-Ciprian
Requires: python 3.x, regex, pandas, matplotlib

Input: input_txt file, inside of the input_data folder. Also, the user cand choose from the command line what he want to count (symbols or letters).
Output: output.csv (where all the letters/symbols apparitions can be found) and graphByAparitions.png/graphByPercentage.png (Letter-Apparitions pivot plot) from output.data file.